=== AMP WooCommerce ===
Contributors: ahmedkaludi, mohammed_kaludi
Tags: WooCommerce, AMP
Donate link: https://www.paypal.me/Kaludi/5
Requires at least: 3.5
Tested up to: 4.6.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WooCommerce for AMP 

== Description ==
Now you can enable AMP on your e-commerce store without any pain. Expect fast updates and support from us because we like to see the happy users. 

== Installation ==
Step 1: Install this plugin
Step 2: Activate this plugin,
Step 3. Done.

== Changelog ==
= 0.1 =
* Initial Release